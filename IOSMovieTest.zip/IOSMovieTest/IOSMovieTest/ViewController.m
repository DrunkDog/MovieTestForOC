//
//  ViewController.m
//  IOSMovieTest
//
//  Created by 赵帅 on 16/9/8.
//  Copyright © 2016年 赵帅. All rights reserved.
//

#import "ViewController.h"
#import <MediaPlayer/MediaPlayer.h>

@interface ViewController ()


//视频播放控制器
@property(nonatomic,strong)MPMoviePlayerController *moviePlayer;
@property(nonatomic,strong)UIActivityIndicatorView *loadingAni;
@property(nonatomic,strong)NSNotificationCenter *notificationCenter;
@property(nonatomic,strong)UIImageView *backMoviePlayer;

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    [self addMediaTableView];
}
-(void)addMediaTableView
{
    
    //头像
    UIImageView * headerImageView=[[UIImageView alloc]init];
    headerImageView.frame=CGRectMake(12,9, 34, 34);
    headerImageView.layer.cornerRadius=17;
    headerImageView.layer.masksToBounds=YES;
    headerImageView.backgroundColor=[UIColor redColor];
    [self.view addSubview:headerImageView];
    
    //昵称
    UILabel *nameLable=[[UILabel alloc]init];
    nameLable.frame=CGRectMake(CGRectGetMaxX(headerImageView.frame)+10, 9, 100, 13);
    nameLable.font=[UIFont systemFontOfSize:14.0f];
    nameLable.textColor=[UIColor colorWithWhite:0.7f alpha:1.0];
    nameLable.text=@"至极无上";
    [self.view addSubview:nameLable];
    
    //角色
    UILabel *typeLable=[[UILabel alloc]init];
    typeLable.frame=CGRectMake(CGRectGetMaxX(headerImageView.frame)+10, CGRectGetMaxY(nameLable.frame)+8, 100, 13);
    typeLable.font=[UIFont systemFontOfSize:14.0f];
    typeLable.textColor=[UIColor colorWithWhite:0.8f alpha:1.0];
    typeLable.text=@"设计师";
    [self.view addSubview:typeLable];
    
    //关注
    UIButton *loveButton=[[UIButton alloc]init];
    loveButton.frame=CGRectMake(self.view.bounds.size.width-12-80,12, 80, 28);
    loveButton.layer.borderColor=[UIColor colorWithWhite:0.7f alpha:1.0].CGColor;
    loveButton.layer.borderWidth=1.0f;
    loveButton.layer.cornerRadius=5;
    loveButton.layer.masksToBounds=YES;
    [loveButton setTitle:@"+关注" forState:UIControlStateNormal];
    [loveButton setTitle:@"取消关注" forState:UIControlStateSelected];
    loveButton.titleLabel.font=[UIFont systemFontOfSize:15.0f];
    [loveButton setTitleColor:[UIColor colorWithWhite:0.7f alpha:1.0] forState:UIControlStateNormal];
    [self.view addSubview:loveButton];
    
    UILabel *lineLable=[[UILabel alloc]init];
    lineLable.frame=CGRectMake(12, CGRectGetMaxY(headerImageView.frame)+9, self.view.bounds.size.width-24, 1);
    lineLable.backgroundColor=[UIColor colorWithWhite:0.8f alpha:1.0];
    [self.view addSubview:lineLable];
    
    //标题
    UILabel *titleNameLabel=[[UILabel alloc]init];
    titleNameLabel.frame=CGRectMake(17, CGRectGetMaxY(lineLable.frame)+12.5, self.view.bounds.size.width-34, 20);
    titleNameLabel.font=[UIFont systemFontOfSize:16.0f];
    titleNameLabel.text=@"大标题";
    titleNameLabel.textColor=[UIColor blueColor];
    [self.view addSubview:titleNameLabel];
    
    
    //视频
    
    UIButton *_mediaPlayerButton=[[UIButton alloc]init];
    _mediaPlayerButton.frame=CGRectMake((self.view.bounds.size.width-60)/2, CGRectGetMaxY(titleNameLabel.frame)+10+(((self.view.bounds.size.width-34)/1.335)-60)/2, 60, 60);
//    [_mediaPlayerButton setImage:[UIImage imageNamed:@""] forState:UIControlStateSelected];//暂停显示
//    [_mediaPlayerButton setImage:[UIImage imageNamed:@""] forState:UIControlStateNormal];//播放时的图片

    [self.view addSubview:_mediaPlayerButton];
    [_mediaPlayerButton addTarget:self action:@selector(moviePlayButton:) forControlEvents:UIControlEventTouchUpInside];
    
    UIImageView*_mediaFirstPictureImage=[[UIImageView alloc]init];
    _mediaFirstPictureImage.frame=CGRectMake(17, CGRectGetMaxY(titleNameLabel.frame)+10, self.view.bounds.size.width-34, 215);
    _mediaFirstPictureImage.backgroundColor=[UIColor colorWithWhite:0.8f alpha:1.0];
    [self.view addSubview:_mediaFirstPictureImage];
    
    UILabel *labef=[[UILabel alloc]init];
    labef.frame=CGRectMake((self.view.bounds.size.width-34-60)/2, 97, 60, 60);
    labef.text=@"点击播放";
    labef.textAlignment=NSTextAlignmentCenter;
    labef.textColor=[UIColor blueColor];
    labef.adjustsFontSizeToFitWidth=YES;
    [_mediaFirstPictureImage addSubview:labef];
    
    if (self.moviePlayer.playbackState==MPMoviePlaybackStatePlaying||self.moviePlayer.playbackState==MPMoviePlaybackStatePaused)
    {
        [self.backMoviePlayer removeFromSuperview];
        [self.moviePlayer.view removeFromSuperview];
        self.moviePlayer=nil;
        
    }
    
    
    
    //浏览次数
    UILabel *liuLanLab=[[UILabel alloc]initWithFrame:CGRectMake(10, CGRectGetMaxY(_mediaFirstPictureImage.frame)+10, 50, 13)];
    liuLanLab.textColor=[UIColor colorWithWhite:0.7f alpha:1.0];
    liuLanLab.font=[UIFont systemFontOfSize:13.0f];
    liuLanLab.text=@"浏览 5";
    [self.view addSubview:liuLanLab];
    
    
    //时间
    UILabel *timeLab=[[UILabel alloc]initWithFrame:CGRectMake(self.view.bounds.size.width-10-90, CGRectGetMaxY(_mediaFirstPictureImage.frame)+10, 80, 13)];
    timeLab.textColor=[UIColor colorWithWhite:0.7f alpha:1.0];
    timeLab.font=[UIFont systemFontOfSize:13.0f];
    timeLab.text=@"08-27 09:00";
    [self.view addSubview:timeLab];
    
    
    
    
}
//视频播放
-(void)moviePlayButton:(UIButton *)sender
{
    if (!_moviePlayer)
    {
        // NSURL *url=[self getNetworkURL];
        NSString *urlStr=@"http://flv2.bn.netease.com/videolib3/1511/19/RiCBl0272/SD/RiCBl0272-mobile.mp4";
        urlStr=[urlStr stringByAddingPercentEscapesUsingEncoding:NSUTF8StringEncoding];
        NSURL *url=[NSURL URLWithString:urlStr];
        
        _moviePlayer=[[MPMoviePlayerController alloc]initWithContentURL:url];
        //_moviePlayer.view.frame=self.view.bounds;
        _moviePlayer.view.frame=CGRectMake(17, 95.5, self.view.bounds.size.width-34, 215);
        _moviePlayer.backgroundView.backgroundColor=[UIColor colorWithWhite:0.85 alpha:0.5];
        _moviePlayer.view.autoresizingMask=UIViewAutoresizingFlexibleWidth|UIViewAutoresizingFlexibleHeight;
        [self.view addSubview:_moviePlayer.view];
        [self.moviePlayer play];
        //添加通知
        [self addNotification];
       
        
    }
    
    
}
-(NSURL*)getNetworkURL
{
    NSString *urlStr=@"http://flv2.bn.netease.com/videolib3/1511/19/RiCBl0272/SD/RiCBl0272-mobile.mp4";
    urlStr=[urlStr stringByAddingPercentEscapesUsingEncoding:NSUTF8StringEncoding];
    NSURL *url=[NSURL URLWithString:urlStr];
    return url;
    
    
}
//视频通知
-(void)addNotification
{
    NSNotificationCenter *notificationCenter=[NSNotificationCenter defaultCenter];
    [notificationCenter addObserver:self selector:@selector(mediaPlayerStateChange:) name:MPMoviePlayerPlaybackStateDidChangeNotification object:self.moviePlayer];
    [notificationCenter addObserver:self selector:@selector(mediaPlayerPlaybackFinished:) name:MPMoviePlayerPlaybackDidFinishNotification object:self.moviePlayer];
    
       
}
-(void)mediaPlayerStateChange:(NSNotification*)notifition
{
    switch (self.moviePlayer.playbackState) {
        case MPMoviePlaybackStatePlaying:
        {
            NSLog(@"正在播放...");
        }
            break;
        case MPMoviePlaybackStatePaused:
        {
            NSLog(@"暂停播放.");
        }
            break;
        case MPMoviePlaybackStateStopped:
        {
            NSLog(@"停止播放.");
            [self.moviePlayer.view removeFromSuperview];
            
        }
            break;
        default:
            NSLog(@"播放状态:%li",self.moviePlayer.playbackState);
            break;
    }
}

-(void)mediaPlayerPlaybackFinished:(NSNotification *)notification{
    NSLog(@"播放完成.%li",self.moviePlayer.playbackState);
    [self.moviePlayer.view removeFromSuperview];
    
}

/**
 *  播放完成
 *
 *  @param notification 通知对象
 */
-(void)mediaPlayerPlayFinished:(NSNotification *)notification
{
    //NSLog(@"播放完成.%li",self.moviePlayer.playbackState);
}


- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

@end
